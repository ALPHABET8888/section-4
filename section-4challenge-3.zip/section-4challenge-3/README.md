# Section 4 - Challenge #3

A Pen created on CodePen.io. Original URL: [https://codepen.io/xnjentxh-the-selector/pen/KKEarWG](https://codepen.io/xnjentxh-the-selector/pen/KKEarWG).

