# section 4 - challenge #2 

A Pen created on CodePen.io. Original URL: [https://codepen.io/xnjentxh-the-selector/pen/poYNvKP](https://codepen.io/xnjentxh-the-selector/pen/poYNvKP).

